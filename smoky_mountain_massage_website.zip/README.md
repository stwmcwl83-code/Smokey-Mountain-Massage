# Smoky Mountain Massage Website

A responsive, single-page website built from the supplied Smoky Mountain Massage materials.

## Included
- Responsive navigation
- Hero / brand section
- Services
- Pricing
- New-client special
- Benefits
- About / foundation
- Vision and goals
- Specialties
- Contact / booking CTA
- Click-to-call and email links
- Supplied brand artwork in `assets/`

## Run locally
Open `index.html` in a browser, or serve the folder with any static web server.

## Contact details used
Phone: 443-985-2120
Email: stwmcwl83@gmail.com
Address: 109 Allegheny Ave
